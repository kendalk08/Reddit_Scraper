import json
import os
import random
import threading
import time
import tkinter as tk
from PIL import Image, ImageTk
from settings import returnSettings as rs

"""
Please adjust default height/width and slide delay in settings.py. This is a standalone program.
"""

with open("sub_list.csv", "r") as filereader:
    subs = filereader.read()

sublist = subs.split("\n")
del sublist[-1]

class SlideShow:

    def pick_subs(self, i):
        if i == 1:
            sub = random.choice(sublist)
            print(sub)
            return self.image_loop(sub)
        sub = random.choice(sublist)
        print(sub)
        self.image_loop(sub)
        return self.pick_subs(i-1)

    def __init__(self, num):
        self.settings = rs()
        self.num = num
        self.height = self.settings["slideshow_height"]
        self.width = self.settings["slideshow_width"]

        self.image_window = tk.Tk()

        self.image_window.geometry(f"900x900")
        self.image_window.bind("<Configure>", self._resize_image)
        image_frame = tk.Frame(self.image_window)
        image_frame.pack(fill="both")
        self.image_label = tk.Label(image_frame, anchor="center", width=900, height=900)
        self.image_label.pack(fill="both")

        thread = threading.Thread(target=self.pick_subs, args=(self.num,))
        thread.daemon = True
        thread.start()

        self.image_window.focus()
        self.image_window.mainloop()

    def _resize_image(self, event):
        self.width = event.width
        self.height = event.height
        self.image_label.configure(height=self.height, width=self.width)

    def image_loop(self, folder, init=False):
        path = os.path.join(os.getcwd(), "images", folder, "_cache.json")
        try:
            with open(path) as fileReader:
                cache = json.load(fileReader)
        except FileNotFoundError:
            print("You must run, Duplicate remover prior to running this.")
        if init:
            return cache[folder]["checked"][0][0]
        else:
            for f in cache[folder]["checked"]:
                try:
                    fi = f[0]
                except IndexError:
                    continue

                l = Image.open(fi)

                w, h = l.size
                if w > h:
                    ya = round(h / (w / self.width))
                    h = ya
                    w = self.width
                else:
                    xa = round(w / (h / self.height))
                    h = self.height
                    w = xa

                l = l.resize((w, h))
                r = ImageTk.PhotoImage(l)

                self.image_label.configure(image=r)

                time.sleep(int(self.settings["slideshow_wait"]))


q = input("Number of random subs to queue?")
a = SlideShow(int(q))
