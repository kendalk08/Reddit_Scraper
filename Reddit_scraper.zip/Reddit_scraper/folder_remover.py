import os
import shutil
from settings import returnSettings as rs

"""
Update number of files in folder to be considered junk in settings.py
Program can be ran by itself
"""

def update_dir():
    cwd = os.getcwd()
    cwd_split = os.path.split(cwd)
    if cwd_split[-1] != "images":
        os.chdir(os.path.join(cwd, "images"))

def clean_subs():
    update_dir()
    settings = rs()
    num_folder = 0
    big_subs = []
    little_subs = []
    directory = os.getcwd()
    total_filesize = 0
    total_filecount = 0
    folder_count = 0

    for root, dirs, file in os.walk(directory):
        for folder in dirs:
            direct = os.path.join(root, folder)
            file_counter = 0
            folder_filesize = 0
            folder_count += 1
            for files in os.listdir(direct):
                file_counter += 1
                folder_filesize += os.path.getsize(os.path.join(direct, files))

            total_filesize += folder_filesize
            total_filecount += file_counter
            if file_counter > 250:
                big_subs.append(folder)
            else:
                little_subs.append(folder)

            if folder not in [".idea", "__pycache__", "inspectionProfiles"]:
                print(f"{folder} contains {file_counter} files. Size: {round((folder_filesize/1024)/1024, 2)} in MBs")
                if file_counter < settings["file_limit"]:
                    print(folder)
                    shutil.rmtree(direct, ignore_errors=True)
                    num_folder += 1

    print(f"Total folders: {folder_count}. Total Files: {total_filecount}"
          f" Total Size: {round((((total_filesize/1024)/1024)/1024), 2)} in GBs.")
    print(f"{num_folder} folders deleted!")

    with open("sub_list.csv", "w") as FileWriter:
        for sub in big_subs:
            FileWriter.write(f"{sub}\n")
        for sub in little_subs:
            FileWriter.write(f"{sub}\n")

    with open("small_subs.csv", "w") as FileWriter:
        for sub in little_subs:
            FileWriter.write(f"{sub}\n")

    with open("big_subs.csv", "w") as FileWriter:
        for sub in big_subs:
            FileWriter.write(f"{sub}\n")


if __name__ == "__main__":
    clean_subs()
