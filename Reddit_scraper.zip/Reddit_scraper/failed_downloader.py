import os
import time
import numpy as np
import requests
import cv2

# Create directory if it doesn't exist to save images
def create_folder(img_path):
    CHECK_FOLDER = os.path.isdir(img_path)
    # If folder doesn't exist, then create it.
    if not CHECK_FOLDER:
        os.makedirs(img_path)

def failed():
    path = os.path.join(os.getcwd(), "failed.csv")
    image_path = os.path.join(os.getcwd(), "images")
    try:
        with open(path, "r") as file_reader:
            failed = file_reader.read()

    except FileNotFoundError:
        print("Failed.csv failed to open!\n Closing in 15 seconds.")
        time.sleep(15)
        quit()
    links = []
    links_list = failed.split("\n")
    links_list.pop()
    for items in links_list:
        new_line = items.split(" ")
        links.append(new_line)

    count = 0
    for link in links:
        if len(link) > 0:
            try:
                resp = requests.get(link[1], stream=True).raw
                image = np.asarray(bytearray(resp.read()), dtype="uint8")
                image = cv2.imdecode(image, cv2.IMREAD_COLOR)

                folder = link[0][:-1]

                print(f"{link[1]} downloaded to {folder}!!")
                subrfolder = os.path.join(image_path, f"{folder}/")
                create_folder(subrfolder)
                cv2.imwrite(f"{subrfolder}{folder}-{count}.png", image)
                count += 1
            except Exception:
                print(f"{link[1]} failed to download! Removing from list")

    try:
        with open(path, "w") as file_clearer:
            file_clearer.write("")
    except FileNotFoundError:
        print("Failed to clear failed.csv!")


if __name__ == "__main__":
    failed()
